$(function() {
    if (opts.debugMode) $('body').addClass('debugmode');
    if (opts.theme !== undefined) $('body').addClass('ui-topology-theme-'+theme);
});