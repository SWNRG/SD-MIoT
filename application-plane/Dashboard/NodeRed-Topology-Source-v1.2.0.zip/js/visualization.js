// Create an Instanse on Graph Container Object - NODE RED EDITION
function TopologyVisualization(opts) { 

// Topology Visualizxation Methods (External Use))

// JSON.stringify(obj1) === JSON.stringify(obj2)
    var prevNodes = null;
    var prevLinks = null;
    var prevFlows = null;
    // NOTRED var prevTimeStamp = null; */

    var loadData = this.loadData = function(data) {
        logupdate();
        //var contWidth = $(opts.svgContainer).innerWidth(),
           // contHeight = $(opts.svgContainer).innerHeight();
            //log(contWidth);log(contHeight);
           // console.log(contWidth);


        /* NOTRED
        if (data.timestamp !== undefined) {
            if (data.timestamp === prevTimeStamp) {
                //log("timstamp same");
                return;
            } else {
                //log("timestamp different");
                prevTimeStamp = data.timestamp;
            }            
        }*/
//console.log(data);
        if (data.cmd !== undefined) {
            if (data.cmd  === 'clearAll') {
                nodes.splice(0, nodes.length + 1);                
                links.splice(0, links.length + 1);
                //var links = force.links();
                //var nodes = force.nodes();
                
                updateGraph();
                //console.log('clear');
            }
        }
        
//NODES
        // Check if Nodes are the same with the file before.
        if (data.nodes !== undefined) {
            if (JSON.stringify(data.nodes) === JSON.stringify(prevNodes)) {
                delete data.nodes;
               // log("Nodes are Same");
            } else {
                prevNodes = data.nodes;
              //  log("Nodes isn't same");
            }
        }   
        
        // Remove Nodes (Nodes on Visualization but not in the Imported Data)
        if (data.nodes !== undefined) { // Do Not Run if Nodes doesn't set 
            var nodeIDsImport = [],
                nodeIDsNow = [];
            if (nodes.length > 0) { // Do Not Run on First Load                
                // Get Node ID list
                $.each(data.nodes, function(nodekey, node) {
                    nodeIDsImport.push(node.id);
                });
                $.each(nodes, function(nodekey, node) {
                    nodeIDsNow.push(node.id);
                });
                // Compair List    
                $.each(nodeIDsNow, function(i,e) { // TODO : Check jQuery.unique() for oposite
                    if ($.inArray(e, nodeIDsImport) == -1) {
                        removeNode(e,false);
                    }
                }); 
                
            }
            
            // Add New Nodes
            var fixonce = false;
            $.each(data.nodes, function(key, node) {
                // Check if Node is already in Visualization
                if ($.inArray(node.id, nodeIDsNow) == -1) {
                    if (opts.fixedRootNode) {
                        // Stick Controler to Center (Only First is Sticked)
                        if (node.type == 1) {
                            if (!fixonce) {
                                //log("fixed : "+node.id);
                                fixonce = true;
                                node.x = contWidth/2;
                                node.y = contHeight/2;
                                node.fixed = true;
                            } else {
                                //log("not fixed : "+node.id);
                                node.fixed = false;  
                            }
                        }
                    }
                    // Add New Node
                    nodes.push(node);
                    
                } else {
                  // Update Node Data
                  updateNode(node.id, node);
                }            
            });
            
            //If controler not found stick first node
            if (opts.fixedRootNode) {
                var detectFixedNode = false;
                $.each(data.nodes, function(key, node) {
                    if (node.fixed) detectFixedNode = true;
                });
                if (!detectFixedNode) {
                   nodes[0].x = contWidth/2;
                   nodes[0].y = contHeight/2;
                   nodes[0].fixed = true;                
                }
            }            
            
            delete nodeIDsImport, nodeIDsNow; // Clean Memory
            refreshStatus();
        }


//LINKS
        // TODO -> BUG IT DOSNT WORK WITH CHARS like '. _' AND OTHERS -> Find Another Way
        // Check if Links are the same with the file before.
        if (data.links !== undefined) {
            if (JSON.stringify(data.links) === JSON.stringify(prevLinks)) {
                delete data.links;
                //log("Links are Same");
            } else {
                prevLinks = data.links;
                //log("Links isn't same");
            }
        }   

        if (data.links !== undefined) { // Do Not Run if Links doesn't set                
            // Clean All Links
            links.splice(0, links.length + 1);
            // Add Links Again : TODO : Fast but Heavy Way -> Make it Better 
            $.each(data.links, function(linkkey, link) {
                addLink(link,false);
            });        
            updateGraph();
            refreshStatus();
//            log(nodes,"NODES");
//            log(links,"LINKS");
        }
//FLOWS      
        // Check if Links are the same with the file before.
        if (data.flows !== undefined) {
            if (JSON.stringify(data.flows) === JSON.stringify(prevFlows)) {
                delete data.flows;
               // log("Flows are Same");
            } else {
                prevFlows = data.flows;
              //  log("Flows isn't same");
            }
        }   

        if (data.flows !== undefined) { // Do Not Run if Flows doesn't set
            //Clear Old Flows
            $("line.link").removeClass('flow');
            $("g.node").removeClass('flow');
            
            $("line.link").removeClass('dashed-animation-forward');
            $("line.link").removeClass('dashed-animation-reverse');
            //$("g.node").removeClass('dashed-animation');
            
            
            $.each(opts.flowColors, function(id, color) {
                $("line.link").removeClass(color);
                $("g.node").removeClass(color);
            });
            
            var autoFlowColor = 1;            
            
            $.each(data.flows, function(flowkey, flow) {

                if (flow.color !== undefined) {
                    if (isNaN(flow.color)) {
                        var flowcolor = flow.color;    
                    } else {
                        var flowcolor = opts.flowColors[flow.color];
                    }
                } else {
                    var flowcolor = opts.flowColorsAuto[autoFlowColor];
                    autoFlowColor++;
                    if (autoFlowColor > opts.flowColorsAuto.length) autoFlowColor = 1;    
                }

                $.each(flow.links, function(key, link) {
                    //Apply Link Flow - Direct and Towards
                    $linkselector = "#lid-" + clearSelector(link.source) + "-" + clearSelector(link.target);
                    $linkselector_reverse = "#lid-" + clearSelector(link.target) + "-" + clearSelector(link.source);
                    
                    if (opts.flowAnimation) {
                                               
                        
                        $($linkselector).addClass("dashed-animation-forward");        
                        $($linkselector_reverse).addClass("dashed-animation-reverse");
                        
                        
                    }

                    $($linkselector).addClass("flow " + flowcolor);        
                    $($linkselector_reverse).addClass("flow " + flowcolor);

                    
                    $nodeSourceSelector = "#nid-" + clearSelector(link.source);
                    $nodeTargetSelector = "#nid-" + clearSelector(link.target);
                    
                    $($nodeSourceSelector).addClass("flow " + flowcolor);        
                    $($nodeTargetSelector).addClass("flow " + flowcolor);
                            
                });
            });
            refreshStatus();
        }                 
                
    }

    /** NOTRED
    this.loadRemoteJSON = function(url) {
        $.getJSON(url, function(data) {
            loadData(data);
        });        
    }

    this.loadLocalJSON = function(url) {
    }
    */

/* *************************************************************************************************/

    var clearAllData = this.clearAllData = function() {
        nodes = [];
        links = [];
        updateGraph();
    }
    
    var clearNodes = this.clearNodes = function() {
        nodes = [];
        updateGraph();
    }

    var clearLinks = this.clearLinks = function() {
        links = [];
        updateGraph();
    }

    // Create a new Node
    var addNode = this.addNode = function(data, update = true) {
        nodes.push(data);
        if (update) updateGraph();
    }
    
    // Detect a Node with ID and remove it from force graph. Also removes all ophan links 
    var removeNode = this.removeNode = function(id, update = true) {
        var i = 0;
        var n = findNode(id);
        while (i < links.length) {
            if ((links[i]['source'] === n) || (links[i]['target'] == n)) links.splice(i, 1);
            else i++;
        }
        var index = findNodeIndex(id);
        if (index !== undefined) {
            nodes.splice(index, 1);
            if (update) updateGraph();
        }
    }

    // Detect a Node with ID and update data on it 
    var updateNode = function(id, newData, update = true) {
        var index = findNodeIndex(id);
        if (index !== undefined) {
            // Update Node Data
            $.each(newData, function(key, newval) {
                nodes[index][key] = newval;
            });
            // Update Node Label | TODO : Find why Force doesen't update label on updateGraph

            if (newData[opts.nodeLabelField] !== undefined) {
                nodetitle = newData[opts.nodeLabelField];//+' ['+node.nid+']'; // TODO : ADD Dynamic LABEL
            } else {
                nodetitle = newData.id;
            }

            $('#nid-'+clearSelector(id)+' .node-label').html(nodetitle);
           
            if (update) updateGraph();
        }
    }
    
    // Create a link between two Nodes (using ID's)
    var addLink = this.addLink = function(link, update = true) {
        //link,sourceID;
       // delete link.Cow;
        var sourceNode = findNode(link.source);
        var targetNode = findNode(link.target);
        
        // Check if Node Exist
        if ((sourceNode !== undefined) && (targetNode !== undefined)) {

            link.source = sourceNode;
            link.target = targetNode;
            
            //link.source = [{ "id": sourceNode.id }];
           // link.target = [{ "id": targetNode.id }];
                        
            links.push(link);
            if (update) updateGraph();
        }
    }

    var removeLink = this.removeLink = function(sourceID, targetID, update = true) {
        var i = 0;
        var index = findLinkIndex(sourceID, targetID);
        if (index !== undefined) {
            links.splice(index, 1);
            if (update) updateGraph();
        }
    }
    
    this.swapLink = function(sourceID, targetID) {
        this.removeLink(sourceID, targetID);
        this.addLink(targetID, sourceID);
    }
    
    var removeAllFixed = function() {
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].fixed !== undefined) nodes[i].fixed = false;            
        };
    }

/* Helpers (Internal Use) */
    var clearSelector = function(selector) {
        return selector.replace(/[^a-zA-Z0-9+]/g, "-");
        //return selector.replace(".", "_");
    }
    
    // Return Node object
    var findNode = function(nodeID) {
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].id === nodeID)
                return nodes[i]
        };
        return null;
    }

    // Return Node Index on Nodes list
    var findNodeIndex = function(nodeID) {
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].id === nodeID)
                return i
        };
        return null;
    }

    // Return Link Object
    var findLink = function(sourceID, targetID) {
        for (var i = 0; i < links.length; i++) {
            if ((links[i].source.id === sourceID) && (links[i].target.id === targetID))
                return links[i]
        };
        return null;
    }

    // Return Link Index on Links list  
    var findLinkIndex = function(sourceID, targetID) {
        for (var i = 0; i < links.length; i++) {
            if ((links[i].source.id === sourceID) && (links[i].target.id === targetID))
                return i
        };
        return null;
    }
    
    var togglePositionLock = function(data) {
        // Fixed/UnFixed Node
        data.fixed = !data.fixed;
        updateNode(data.id, data);
    }

    // Used on Zoom set scale
    var reDraw = function() {
        vis.attr("transform",
            "translate(" + d3.event.translate + ") " +
            "scale(" + d3.event.scale + ")"
        );
    }

/** ToolTip */
    
    var tooltipTimeOut;

    var updateToolTipPos = function(pageY,pageX) {
        tooltip.style("top", (pageY - $('#ui-topology-tooltip').height() - 25 )+"px").style("left",(pageX + 5 )+"px");        
    }  
    
    var tooltipData = null;

    refreshTooltipData = function() {
        if (tooltipData) {
            switch (tooltipData.type) {
                case "node":
                    tooltipNode = findNode(tooltipData.data.id);
                    if (tooltipNode) {
                        updateNodeToolTip(tooltipNode);
                    } else {
                        hideToolTip();
                    }
                break;
                case "link":
                    tooltipLink = findLink(tooltipData.data.source.id,tooltipData.data.target.id);
                    if (tooltipLink) {
                        updateLinkToolTip(tooltipLink);
                    } else {
                        hideToolTip();
                    }
                break;
            }
        }
    }
        
    var updateNodeToolTip = function(nd) {
        tooltipData = {
            "type":"node",
            "data":nd
        }
        
        var nodeInfo = '';
        nodeInfo += drawToolTipLine("ID",nd.id);
        switch(nd.type) {
            case 'controler':
            case 1:
                nodeInfo += drawToolTipLine("Type","Controler");
                break;
            case 'node':
            case 2:
                nodeInfo += drawToolTipLine("Type","Node");
                break;
        }        
        $.each(nd.data, function(key, value) {
            nodeInfo += drawToolTipLine(key,value);
        });
        tooltip.html(nodeInfo)
    }
    
    var updateLinkToolTip = function(ld) {
        tooltipData = {
            "type":"link",
            "data":ld
        }
        var linkInfo = '';
        //linkInfo += drawToolTipLine("ID",ld.id);
        $.each(ld.data, function(key, value) {
            linkInfo += drawToolTipLine(key,value);
        });
        tooltip.html(linkInfo)
    }
    
    
    var showToolTip = function() {
        tooltipTimeOut = setTimeout(function(){ 
            tooltip.style("visibility", "visible");
            tooltipTimeOut = null;    
        }, 500);
    }
    
    var hideToolTip = function() {
        clearTimeout(tooltipTimeOut);
        tooltipTimeOut = null;
        tooltip.style("visibility", "hidden");
    }

    var drawToolTipLine = function(key,value) {
        return '<div><font class="label"><b>'+key+' : </b></font><font class="value">'+value+'</font></div>';
    }

/* Status */
    var refreshStatus = function() {
        //var d = new Date();
        //$("#status" ).html(d.toLocaleDateString() +" " + d.toLocaleTimeString());
    }

/* Actions */

    // Raise Event On Node Click ->TODO
    var nodeClick = function(data) {
        
        switch (true) {
            case ((d3.event.shiftKey) && (d3.event.ctrlKey)):
                returnAction(data,"shiftctrlClick");
                break;
            case ((d3.event.altKey) && (d3.event.ctrlKey)):
                returnAction(data,"altctrlClick");
                break;
            case ((d3.event.altKey) && (d3.event.shiftKey)):
                returnAction(data,"altshiftClick");
                break;
            case (d3.event.shiftKey):
                returnAction(data,"shiftClick");
                break;
            case (d3.event.ctrlKey):
                returnAction(data,"ctrlClick");
                break;
            case (d3.event.altKey):
                // Fixed/UnFixed Node
                togglePositionLock(data);
                //returnAction(data,"altClick");
                break;
            default: // click only
                log(data,"Node Data");
                break;
        }
        
       /* if(d3.event.shiftKey){
            alert(d3.event.shiftKey);
            returnNodeID(data,"shiftclick");                        
        } else {
            log(data,"Node Data");    
        }*/
        
        
//            if (d3.event.shiftKey) modifiers += '⇧';
//            if (d3.event.ctrlKey) modifiers += '⌃';
//            if (d3.event.altKey) modifiers += '⌥';
//            if (d3.event.metaKey) modifiers += '⌘';        
        
    }
    
    var nodeMouseOver = function(nd) {
        updateNodeToolTip(nd);
        showToolTip();
    }

    var nodeMouseMove = function(nd) {
        updateNodeToolTip(nd);        
        updateToolTipPos(d3.event.pageY,d3.event.pageX)
    }
    
    var nodeMouseOut = function() {
        hideToolTip();
    }
    
    var nodeDblClick = function(data) {
    //    d3.select("svg").on("dblclick.zoom", null);
        //zoom.on('zoom', null);
        //zoom.on("dblclick.zoom", null);
        
        
        //data.fixed = !data.fixed;
        //updateNode(data.id, data);
        
        
        
       // setTimeout(enablezoom, 500);        

    }

    var enableZoom = function() {
      //  zoom.on('zoom', reDraw);
    //  d3.select("svg").on("dblclick.zoom", reDraw);
      
    }

    // Raise Event On Link Click ->TODO
    var linkClick = function(data) {
        log(data,"Link Data");
    }

    var linkMouseOver = function(ld) {
        updateLinkToolTip(ld);
        showToolTip();
    }

    var linkMouseMove = function(ld,event) {
        updateLinkToolTip(ld); 
        updateToolTipPos(d3.event.pageY,d3.event.pageX)
    }
    
    var linkMouseOut = function() {
        hideToolTip();
    }
    
/* Force Variables */

    // set up the D3 visualisation in the specified element
    var contWidth = $(opts.svgContainer).innerWidth(),
        contHeight = $(opts.svgContainer).innerHeight();

    // Create d3 behaivior
    // var zoom = d3.behavior.zoom().scaleExtent([0.5, 5]);
    var scale = opts.initScale;

    var zoomWidth = (contWidth-scale*contWidth)/2;
    var zoomHeight = (contHeight-scale*contHeight)/2;
       
    var zoom = d3.behavior.zoom().translate([zoomWidth,zoomHeight]).scale(scale).scaleExtent([opts.minScale, opts.maxScale]);
        
       // console.log(contWidth);
       // console.log(zoomWidth);

    var vis = this.vis = d3.select(opts.svgContainer).append("svg")
        .call(zoom.on("zoom", reDraw))
        .attr("width", "100%")
        .attr("height", "100%")
        .append("g")
        .attr("transform", "translate("+zoomWidth+","+zoomHeight+") scale("+scale+")");
       // .style("position", "absolute");

    // Force Graph Instance - TODO Add to opts
    var force = d3.layout.force()
        .charge(function(d){ // TODO : Check here to undestand what is this : http://stackoverflow.com/questions/29639270/space-out-nodes-evenly-around-root-node-in-d3-force-layout
            var charge = opts.charge;
            if (d.index === 0) charge = 10 * charge;
            //charge =1000;
            return charge;
        })
        .gravity(opts.gravity)
        .distance(opts.distance)
        //.charge(-100)
        .size([contWidth, contHeight])
        .on('end', function() { 
            //removeAllFixed();
        });
       // .size([contWidth, contHeight]);

    // Force Graph Links and Nodes lists
    var links = force.links();
    var nodes = force.nodes();

// ToolTip Holder tooltip -> ui-topology-tooltip
    var tooltip = d3.select("body")
    	.append("div")
        .attr("id", "ui-topology-tooltip") 
    	.style("position", "absolute")
    	.style("z-index", "10")
    	.style("visibility", "hidden")
    	.text("");

    //Discover neighbor nodes ή Discover neighbors Message=Send Data Message ή Send Message
    
    var menuNode = [
        {
            title: function(d) {
                return 'Node '+d.id;
            },
        },   
        {
            divider: true
        },         
        {
            title: function(d) {
                return 'Discover Neighbors';
            },
            action: function(elm, d, i) {
                returnAction(d,"topology");
            }
            //disabled: false
        },
        {
            title: 'Send Message',
            action: function(elm, d, i) {
                returnAction(d,"message");
            }
        },
        {
            title: function(d) {
                if (d.fixed) {
                    return 'Unlock Position';                    
                } else {
                    return 'Lock Position';    
                }                
            },
            action: function(elm, d, i) {
                togglePositionLock(d);
            }
            //disabled: false
        },
        
    ];

console.log(menuNode);


    // Refresh Graph
    var updateGraph = function() {

        // Hide Tooltip ? Why?
        // tooltip.style("visibility", "hidden");
        refreshTooltipData();
        
        // Drag behaivor - Disable some transitions while dragging
        var drag = force.drag();
        drag.on('dragstart', function(n) {
                clearTimeout(tooltipTimeOut); // Clear ToolTip Time Out
                d3.event.sourceEvent.stopPropagation();
                zoom.on('zoom', null);
            })
            // Re-enable transitions when dragging stops
            .on('dragend', function(n) {
                zoom.on('zoom', reDraw);
            })
            .on("drag", function(d) {
                // Avoid pan & drag conflict
                clearTimeout(tooltipTimeOut); // Clear ToolTip Time Out
                d3.select(this).attr("x", d.x = d3.event.x).attr("y", d.y = d3.event.y);
            });


        var link = vis.selectAll("line.link")
            .data(links, function(lnk) {
                return lnk.source.id + "-" + lnk.target.id;
            });
            
        link.enter().insert("line")
            .attr("id", function(ld) {
                return "lid-" + clearSelector(ld.source.id) + "-" + clearSelector(ld.target.id);
            })
            .attr("class", function(ld) {
                if (ld.class === undefined) {
                    return "link";
                } else {
                    return "link" + ld.class;
                }                
            })
            .on("click", linkClick)
            .on("mouseover", linkMouseOver)                
        	.on("mousemove", linkMouseMove)
            .on("mouseout", linkMouseOut);

        link.exit().remove();
        

        

// NODES
        var node = vis.selectAll("g.node")
            .data(nodes, function(d) {
                return d.id;
            });           
            
        var nodeEnter = node.enter().append("g")
            .attr("id", function(nd) {
                return clearSelector("nid-" + nd.id);
            })
            .attr("class", function(nd) {
                if (nd.class === undefined) {
                    return "node";
                } else {
                    return "node " + nd.class;
                }                
            })
            .on("click", nodeClick)
            .on("dblclick", nodeDblClick) // TODO : Fix Double Click ZOOM         
            .on("mouseover", nodeMouseOver)                
        	.on("mousemove", nodeMouseMove)
            .on("mouseout", nodeMouseOut)
            //.on('contextmenu', d3.contextMenu(menu))
            
            .on('contextmenu', d3.contextMenu(menuNode, {
                onOpen: function(data) {
                    //console.log(data);
                },
                onClose: function(data) {
                    //console.log(data);
                }
            }))            
            
            .call(drag);

        // Create Back Circle
        nodeEnter.append("circle")
            .attr("class", "nodecircle")
            .attr("r", opts.nodeCircleSize);

        // Add Image in the front of Circle
        nodeEnter.append("image")
            .attr("class", "nodeimage")
            //.attr("xlink:href", "tower.png")
            .attr("xlink:href", function(node) {
                var nodeIcon = "none.png";
                switch(node.type) { // TODO : Add images into array and get from ID
                    case 'controler':
                    case 1:
                        nodeIcon = "server.png";
                        break;
                    case 'node':
                    case 2:
                        nodeIcon = "tower.png";
                        break;
                }
                return NodeIconsPath + nodeIcon;
            })
            .attr("x", -1 * (opts.nodeImageSize/2))
            .attr("y", -1 * (opts.nodeImageSize/2))
            .attr("width", opts.nodeImageSize)
            .attr("height", opts.nodeImageSize);

        // Create Hover Circle - TODO : FIX it with one object later
        nodeEnter.append("circle")
            .attr("class", "nodehover")
            .attr("r", 18);

        // Create Label
        nodeEnter.append("text")
            .attr("class", "node-label")
            .attr("dx", 0)
            .attr("dy", (-1 * opts.nodeLabelDistance)+"em")
            .text(function(node) {
                if (node[opts.nodeLabelField] !== undefined) {
                    return node[opts.nodeLabelField];//+' ['+node.nid+']'; // TODO : ADD Dynamic LABEL
                } else {
                    return node.id;
                }
            });
            
        node.exit().remove();

        // Init Force Changes

//var w = contWidth;
//var h = contHeight;

        force.on("tick", function(e) {
            
            link.attr("x1", function(d) {
                    return d.source.x;
                })
                .attr("y1", function(d) {
                    return d.source.y;
                })
                .attr("x2", function(d) {
                    return d.target.x;
                })
                .attr("y2", function(d) {
                    return d.target.y;
                });

            node.attr("transform", function(d) {
                return "translate(" + d.x + "," + d.y + ")";
            });
        });
        

        // Restart the force layout.
        force.start();

        // Trick/Patch : Fix SVG Line object layer order - Set it to appear on the back of Nodes
        // TODO : This problem appears because if you add links after update it will add it after all other objects. Find Solution instead of this patch.
        $("svg .link").insertBefore("svg .node:first");
    }

    // Draw Graph on First Instance
    updateGraph();

}; // End TopologyVisualization



/******** KEEP NOTES ******************************/


// LINKS
/*
        var link = vis.selectAll("g.link")
            .data(links, function(lnk) {
                return lnk.source.id + "-" + lnk.target.id;
            });
            

        var linkEnter = link.enter().append("g")
            .attr("class", "link")
            .on("click", linkClick)
            .on("mouseover", linkHover);

        linkEnter.append("line")
            .attr("class", "link _path _dashed");
            
        link.exit().remove();
*/

