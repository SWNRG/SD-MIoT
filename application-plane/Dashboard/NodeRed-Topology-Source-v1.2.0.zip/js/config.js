    var opts = {
        //Application
        //refreshTime : 3000, // Milliseconds
        //jsonURL : "data",
        // Document
        svgContainer: "#ui-topology-container",
        // D3 & Force Options
        charge: -400, //-400
        gravity: 0.05,
        distance: 60, // 120
        initScale : 1,//0.7,
        minScale : 0.5,
        maxScale : 5,
        // Node Design        
        nodeLabelField: "title",
        nodeCircleSize: 18,
        nodeImageSize : 24,
        nodeLabelDistance: 2.2,
        fixedRootNode: true,
        // Flows Design
        flowAnimation : true,
        //Colors Palette
        flowColors : flowColorsPallete,        
        flowColorsAuto : flowColorsAuto,
        //Demo
        //demoData : true, // Loads Demo Data
        //demoStepFrom : 1,
        //demoStepTo : 4,
        //demoLoop: true,
        /* Debug */
        //debugMode : true,
        /* Theme */
        //theme : 'grayscale',
    };
