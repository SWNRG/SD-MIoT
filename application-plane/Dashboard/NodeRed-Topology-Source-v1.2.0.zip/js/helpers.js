/** LOG Helpers */
function log(jsObj, title=" ") {
   if (opts.debugMode) {
       if (title) { title = "\n--------------------\n" + title + "\n--------------------\n" };
       $("#logoutput" ).prepend(title+JSON.stringify(jsObj, null, "\t")+"\n ============================================ \n" );
   } else {
      // if (title) { title = "\n--------------------\n" + title + "\n--------------------\n" };
       msg = {};
       msg.title = title;
       msg.resptype = 'debugLog';
      
       msg.payload = JSON.stringify(jsObj,null,2);
       topologyscope.send(msg);
   }
}

function logupdate() {
   if (opts.debugMode) {
       var d = new Date();
       $("#updatetime" ).html("<b>LAST UPDATE : </b>\n"+d.toString());
   } else {
       var d = new Date();
       msg = {};
       msg.title = 'Last Update';
       msg.resptype = 'debugLog';
       //var datestring = d.toString().split("(");
       //msg.payload = datestring[0];
       msg.payload = d.toLocaleDateString() +" " + d.toLocaleTimeString();
       topologyscope.send(msg);
   }
}