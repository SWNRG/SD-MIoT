
function returnAction(data, command) {
   msg = {};
   msg.command = command;
   msg.payload = JSON.stringify(data,null,2);
   topologyscope.send(msg);
}